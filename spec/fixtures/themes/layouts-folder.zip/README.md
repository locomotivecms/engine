# Website Structure

## homepage

* background image (randomly rotate : use jquery cycle) (pull these from an asset collection)
* navigation bar
* newsletter signup
* footer
* [*] social media links - model (icon, url)
* logo
* Did you know section
* Event listing - model (description, date, url? [Ashley will check on this])
* Special notice (order yearbook now)

